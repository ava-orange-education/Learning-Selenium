package uiscreens;

import org.openqa.selenium.By;

public class HomePageUI {

	public static By searchfield = By.xpath("//input[@placeholder='Search']");

}
