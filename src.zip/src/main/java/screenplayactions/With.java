package screenplayactions;

import org.openqa.selenium.WebDriver;

public class With {

	public static void URL(WebDriver driver, String URL) {
		driver.get(URL);
	}

}
