package base;

import java.util.Properties;

public interface PropertyReader {
	
	
	public Properties getStaticData();

}
