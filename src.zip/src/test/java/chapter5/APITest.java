package chapter5;

import testzeus.base.HTTPClientWrapper;

public class APITest {

	public static void main(String[] args) {
		HTTPClientWrapper.runGetRequest("https://www.google.com");

	}

}
